## Tabling predicate reference

  * [[(table)/1]]
  * [[current_table/1]]
  * [[abolish_all_tables/0]]
  * [[abolish_table_subgoals/1]]


